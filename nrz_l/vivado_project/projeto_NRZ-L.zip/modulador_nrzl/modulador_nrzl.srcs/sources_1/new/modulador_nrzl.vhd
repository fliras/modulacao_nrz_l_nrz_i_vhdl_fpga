library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity modulador_nrzl is
    generic (
        NUM_BITS: integer := 16; -- número de bits a serem transmitidos
        CICLOS_POR_BIT: integer := 2000  -- número de ciclos de clock por bit
    );
    port (
        clock: in  std_logic; -- porta que representa o sinal de clock
        entrada: in  std_logic_vector(0 to NUM_BITS-1); -- input do testbench ou dos switches da placa física
        saida_testbench: out std_logic; -- output no waveform (via testbench)
        saida_leds: out std_logic_vector(0 to NUM_BITS-1) -- output nos leds da placa física
        
    );
end entity;

architecture Behavioral of modulador_nrzl is
    -- indicação do bit atual sendo transmitido.
    signal bit_index   : integer range 0 to NUM_BITS := 0;
    
    -- contador que controla a duração de cada bit em ciclos de clock.
    signal contador_clock : integer range 0 to CICLOS_POR_BIT := 0;
    
    -- registro para armazenar o estado dos LEDs, inicializado com '0' (todos apagados).
    signal leds_reg: std_logic_vector(0 to NUM_BITS-1) := (others => '0');
begin
    -- linkagem do registro de LEDs à saída dos LEDs da placa física.
    saida_leds <= leds_reg;

    process(clock)
    begin
        if rising_edge(clock) then -- se houver uma borda de subida no clock, o processo é executado
            if bit_index < NUM_BITS then -- verifica se ainda há bits para transmitir
                saida_testbench <= entrada(bit_index); -- modifica sinal no waveform;
                leds_reg(bit_index) <= entrada(bit_index); -- acende/apaga o led respectivo ao bit;

                if contador_clock < CICLOS_POR_BIT - 1 then -- verifica se ainda não terminou o período do bit atual.
                    contador_clock <= contador_clock + 1;
                else -- se terminou, reinicia o contador e passa para o próximo bit.
                    contador_clock <= 0;
                    bit_index   <= bit_index + 1;
                end if;

            else -- se a sequência foi transmitida, reinicia tudo para o próximo ciclo de transmissão.
                bit_index <= 0;
                contador_clock <= CICLOS_POR_BIT - 1; -- põe o contador do clock no final para reiniciar pulso corretamente
                leds_reg <= (others => '0');
            end if;

        end if;
    end process;

end Behavioral;