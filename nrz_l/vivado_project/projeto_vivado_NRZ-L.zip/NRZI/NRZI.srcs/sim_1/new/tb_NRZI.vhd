library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_NRZI is
end entity;

architecture Behavioral of tb_NRZI is

    -- o PERIODO_CLOCK a 100ns garante uma frequência de de 10MHz
    constant PERIODO_CLOCK: time := 100 ns;
    constant PERIODO_BIT: time := 200 ns;
    constant N_BITS: integer := 16;

    signal clock: std_logic := '0';
    signal entrada: std_logic_vector(0 to N_BITS-1) := "1011001110001111";
    signal saida_testbench : std_logic;
    signal saida_analog : std_logic;

begin

    -- clock contínuo
    clock <= not clock after PERIODO_CLOCK/2;

    -- DUT
    UUT: entity work.NRZI_Source
        generic map (
            CICLOS_POR_BIT => PERIODO_BIT/PERIODO_CLOCK,
            N_BITS => N_BITS
        )
        port map (
            clock => clock,
            entrada => entrada,
            saida_testbench => saida_testbench,
            saida_analog => saida_analog
        );

end Behavioral;