library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity NRZI_Source is
    generic (
        CICLOS_POR_BIT : integer := 2000;   -- ciclos de clock por bit
        N_BITS         : integer := 16
    );
    port (
        clock      : in  std_logic;
        entrada    : in  std_logic_vector(0 to N_BITS-1);
        saida_testbench: out std_logic;
        saida_analog: out std_logic;
        saida_leds : out std_logic_vector(0 to N_BITS-1)
    );
end entity;

architecture Behavioral of NRZI_Source is

    signal bit_index       : integer range 0 to N_BITS := 0;
    signal contador_clock  : integer range 0 to CICLOS_POR_BIT := CICLOS_POR_BIT - 1;
    signal nivel           : std_logic := '0';  -- nível atual do sinal NRZI
    signal leds_reg        : std_logic_vector(0 to N_BITS-1) := (others => '0');

begin

    -- Conecta o registrador interno à saída
    saida_leds <= leds_reg;

    process(clock)
    begin
        if rising_edge(clock) then

            if bit_index < N_BITS then

                if contador_clock < CICLOS_POR_BIT - 1 then
                    contador_clock <= contador_clock + 1;
                else
                    -- Em NRZI, há transição apenas quando o bit de entrada é '1'
                    if entrada(bit_index) = '1' then
                        nivel <= not nivel;
                        leds_reg(bit_index) <= not nivel;  -- valor após a transição
                    else
                        leds_reg(bit_index) <= nivel;      -- mantém o nível atual
                    end if;
                    
                    saida_testbench <= nivel;
                    saida_analog <= nivel;
                    contador_clock <= 0;
                    bit_index <= bit_index + 1;
                end if;

            else
                -- Reinicia a transmissão e limpa as saídas
                bit_index      <= 0;
                saida_analog <= '0';
                contador_clock <= CICLOS_POR_BIT - 1;
                nivel          <= '0';
                leds_reg       <= (others => '0');
            end if;

        end if;
    end process;

end Behavioral;