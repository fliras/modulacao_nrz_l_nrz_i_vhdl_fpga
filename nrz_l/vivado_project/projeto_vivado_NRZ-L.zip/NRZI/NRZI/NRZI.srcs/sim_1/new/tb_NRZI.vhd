library IEEE;

use IEEE.STD_LOGIC_1164.ALL;
entity tb_NRZI is

end tb_NRZI;

architecture Behavioral of tb_NRZI is

    constant bits : time := 20ns;
    constant clk_per : time := 10 ns;
    Signal clk       : STD_LOGIC := '0';
    Signal reset     : STD_LOGIC := '0';
    Signal o_swv   : STD_LOGIC_VECTOR(15 downto 0) := x"A5A5";
    Signal nrzi_out  : STD_LOGIC;

begin

    clk <= not clk after clk_per/2;

    UUT: entity work.NRZI_Source
        generic map (ciclos => 2)
        port map (
            clk => clk, 
            reset => reset, 
            o_swv => o_swv, 
            nrzi_out => nrzi_out
        );

    process begin
        reset <= '1';
        wait for 20 ns;
        reset <= '0';
        
        wait for 16 * bits;        
        wait;
    end process;

end Behavioral;