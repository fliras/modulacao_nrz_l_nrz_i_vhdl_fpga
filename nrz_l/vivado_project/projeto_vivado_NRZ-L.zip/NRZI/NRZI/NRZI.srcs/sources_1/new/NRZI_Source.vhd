library IEEE;

use IEEE.STD_LOGIC_1164.ALL;

use IEEE.NUMERIC_STD.ALL;

entity NRZI_Source is

    Generic (
            ciclos  : INTEGER := 2
    );

    Port ( 
            clk     : in  STD_LOGIC;
            reset   : in  STD_LOGIC;
            o_swv : in  STD_LOGIC_VECTOR(15 downto 0);
            nrzi_out: out STD_LOGIC
         );
end NRZI_Source;

architecture Behavioral of NRZI_Source is
    signal i : INTEGER range 0 to 15 := 0;
    signal aux_signal : std_logic := '0';

begin
    process(clk, reset) begin
        if reset = '1' then
            i <= 0;
            aux_signal <= '0';
        elsif rising_edge(clk) then

            if (o_swv(i) = '1') then
                aux_signal <= not aux_signal; -- Inverte se o bit for 1
            else
                aux_signal <= aux_signal;     -- Mantém se o bit for 0[cite: 1]
            end if;
                
            if (i = 15) then
                i <= 0;
            else
                i <= i+1;
            end if;

        end if;
    end process; 
    nrzi_out <= aux_signal;   

end Behavioral;

